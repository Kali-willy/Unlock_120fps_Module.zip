#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

# Reset all properties we've set
resetprop --delete ro.fps.high
resetprop --delete ro.surface_flinger.running_without_sync_framework
resetprop --delete ro.surface_flinger.vsync_event_phase_offset_ns
resetprop --delete ro.surface_flinger.vsync_sf_event_phase_offset_ns
resetprop --delete persist.vendor.display.lcd.fps
resetprop --delete ro.vendor.display.default_fps

# Remove log files
rm -rf /data/local/tmp/fps_unlock_log

# Kill any running instances of our service scripts
pkill -f "fps_unlock" 