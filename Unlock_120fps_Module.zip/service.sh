#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode
# Sleep to ensure system is fully booted
sleep 30

# Game package names
GAME_PACKAGES=(
  "com.mobile.legends"
  "com.tencent.ig"
  "com.tencent.iglite"
  "com.pubg.krmobile"
  "com.vng.pubgmobile"
  "com.rekoo.pubgm"
  "com.activision.callofduty.shooter"
  "com.garena.game.codm"
)

# Apply settings when games are detected running
while true; do
  for pkg in "${GAME_PACKAGES[@]}"; do
    if [ "$(pidof $pkg)" != "" ] || [ "$(pgrep -f $pkg)" != "" ]; then
      # Set refresh rate to 120Hz
      service call SurfaceFlinger 1035 i32 0 i32 120
      
      # Game is running, apply boosted settings
      settings put global debug.hwui.renderer skiagl
      settings put global debug.egl.hw 1
      settings put global debug.hwui.profile true
      settings put global debug.composition.type gpu
      settings put global debug.gr.swapinterval 0
      settings put global debug.sf.latch_unsignaled 1
      settings put global debug.sf.enable_gl_backpressure 0
      
      # Log the application that triggered high FPS mode
      echo "High FPS mode enabled for $pkg - $(date)" >> /data/local/tmp/fps_unlock_log/app_triggers.log
      
      # Sleep to avoid excessive CPU usage
      sleep 10
    fi
  done
  
  # Check every 5 seconds
  sleep 5
done & 